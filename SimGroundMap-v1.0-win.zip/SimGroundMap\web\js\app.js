// Bootstrap + polling orchestration - ties api.js/airports.js/map.js/gps.js/
// settings.js together. No framework/build step (see NOTES.md (section 27)):
// this file just owns a handful of setInterval loops, each guarded against
// overlapping itself if a request is slow.
import { api } from "./api.js";
import { initAirportsPanel, renderAirportsPanel, icaosInPlan } from "./airports.js";
import { initMapPanel, setActiveIcao, getActiveIcao, setMapData, setTaxiNetwork, setRouteSelection, setLiveAircraft, setMapLoadStatus, setAtisForActiveAirport } from "./map.js";
import { initGpsStream } from "./gps.js";
import { initSettingsPanel } from "./settings.js";

const AIRPORTS_POLL_MS = 2000;
const MAP_POLL_MS = 1500;
const ATIS_POLL_MS = 8000;

let atisNetwork = 0;
let atisByIcao = {}; // icao -> AtisResult | undefined (undefined = never fetched)
let atisLastFetch = {}; // icao -> timestamp
let taxiNetworkFetchedFor = null;

const connStatus = document.getElementById("conn-status");
function setConnStatus(ok, text) {
    connStatus.textContent = text;
    connStatus.className = "conn-status " + (ok ? "ok" : "bad");
}

// Collapses the DEP/DEST/ALT list to give the map the full width - real-
// usage request, see NOTES.md. Per-browser (localStorage), not synced via
// /api/settings - see style.css's #main.list-collapsed comment for why.
const LIST_COLLAPSED_KEY = "sgm-list-collapsed";
const mainEl = document.getElementById("main");
const collapseBtn = document.getElementById("collapse-btn");
function setListCollapsed(collapsed) {
    mainEl.classList.toggle("list-collapsed", collapsed);
    collapseBtn.innerHTML = collapsed ? "&raquo; Show list" : "&laquo; Hide list";
    collapseBtn.title = collapsed ? "Show the airport list" : "Hide the airport list";
    localStorage.setItem(LIST_COLLAPSED_KEY, collapsed ? "1" : "0");
}
collapseBtn.addEventListener("click", () => setListCollapsed(!mainEl.classList.contains("list-collapsed")));
setListCollapsed(localStorage.getItem(LIST_COLLAPSED_KEY) === "1");

function selectIcao(icao) {
    if (icao === getActiveIcao()) return;
    setActiveIcao(icao);
    taxiNetworkFetchedFor = null;
    setAtisForActiveAirport(atisByIcao[icao]); // don't wait for the next ATIS poll tick if already fetched
}

initAirportsPanel({ onSelectIcao: selectIcao });
initMapPanel({
    onEdgeClicked: (edgeIndex) => {
        const icao = getActiveIcao();
        if (icao) api.clickTaxiRouteEdge(icao, edgeIndex);
    },
    onClearRoute: () => {
        const icao = getActiveIcao();
        if (icao) api.clearTaxiRoute(icao);
    },
});
const settingsPanel = initSettingsPanel({
    onSettingsChanged: (settings) => {
        atisNetwork = settings.atisNetwork;
    },
});
initGpsStream(
    (data) => setLiveAircraft(data),
    (ok) => setConnStatus(ok, ok ? "live" : "GPS stream disconnected")
);

let airportsPollBusy = false;
async function pollAirports() {
    if (airportsPollBusy) return;
    airportsPollBusy = true;
    try {
        const res = await api.getAirports();
        if (!res.ok) {
            setConnStatus(false, "API unreachable");
            return;
        }
        setConnStatus(true, "connected");
        renderAirportsPanel(res.body, atisByIcao, atisNetwork, getActiveIcao());

        const icaos = icaosInPlan(res.body);
        const now = Date.now();
        for (const icao of icaos) {
            const last = atisLastFetch[icao] || 0;
            if (now - last >= ATIS_POLL_MS) {
                atisLastFetch[icao] = now;
                api.getAtis(icao).then((r) => {
                    atisByIcao[icao] = r.ok ? r.body : undefined; // 404 = not fetched yet server-side
                    if (icao === getActiveIcao()) {
                        setAtisForActiveAirport(atisByIcao[icao]);
                    }
                });
            }
        }
    } catch {
        setConnStatus(false, "API unreachable");
    } finally {
        airportsPollBusy = false;
    }
}

let mapPollBusy = false;
async function pollMap() {
    const icao = getActiveIcao();
    if (!icao || mapPollBusy) return;
    mapPollBusy = true;
    try {
        const res = await api.getAirportMap(icao);
        if (res.status === 202) {
            setMapLoadStatus("Loading airport data...");
        } else if (res.status === 404) {
            setMapLoadStatus(res.body?.error || "Airport not found in apt.dat.");
        } else if (res.ok) {
            setMapData(res.body);
            if (res.body.hasTaxiRouteNetwork && taxiNetworkFetchedFor !== icao) {
                taxiNetworkFetchedFor = icao;
                const net = await api.getTaxiNetwork(icao);
                if (net.ok) setTaxiNetwork(net.body);
            }
            if (res.body.hasTaxiRouteNetwork) {
                const route = await api.getTaxiRoute(icao);
                if (route.ok) setRouteSelection(route.body);
            }
        }
    } finally {
        mapPollBusy = false;
    }
}

async function init() {
    const res = await api.getSettings();
    if (res.ok) {
        atisNetwork = res.body.atisNetwork;
        settingsPanel.populate(res.body); // also applies accent/opacity, see settings.js
        if (res.body.version) {
            document.getElementById("app-version").textContent = "v" + res.body.version;
        }
    }
    pollAirports();
    setInterval(pollAirports, AIRPORTS_POLL_MS);
    setInterval(pollMap, MAP_POLL_MS);
}

init();
